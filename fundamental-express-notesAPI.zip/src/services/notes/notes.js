const notes = [];

export default notes;